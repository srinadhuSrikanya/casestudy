package com.adminservice.systemadmin.controller;

import java.util.Optional;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.adminservice.systemadmin.model.FarmerDetails;
import com.adminservice.systemadmin.repo.AdminRepository;

@RestController
public class AdminController {
	
	@Autowired
	AdminRepository repo;
	
	 @RequestMapping(value="/farmer",method=RequestMethod.GET)
	  public Optional<FarmerDetails> getAdminDetails(@PathVariable String id) {
		return repo.findById(id);
	  }
	 
	 @RequestMapping(value="/addfarmer",method=RequestMethod.POST)
	  public void addFarmerDetails(@RequestBody FarmerDetails crops) {
		  repo.insert(crops);
	  }
	
	 //@RequestMapping(value="/putfarmer",method=RequestMethod.PUT)
	 // public void addAdminDetails(@RequestBody FarmerDetails farmers) {
	//	  repo.insert(farmers);
	 // }

	 @RequestMapping(value="/farmer",method=RequestMethod.DELETE)
	  public void deleteCropsDetails(@PathVariable String userName) {
	    repo.deleteById(userName);
	  }
}
