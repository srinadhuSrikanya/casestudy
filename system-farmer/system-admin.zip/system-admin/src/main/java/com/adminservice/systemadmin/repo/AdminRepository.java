package com.adminservice.systemadmin.repo;

import org.springframework.data.mongodb.repository.MongoRepository;

import org.springframework.stereotype.Repository;


import com.adminservice.systemadmin.model.FarmerDetails;

@Repository
public interface AdminRepository extends MongoRepository<FarmerDetails, String> {

}
