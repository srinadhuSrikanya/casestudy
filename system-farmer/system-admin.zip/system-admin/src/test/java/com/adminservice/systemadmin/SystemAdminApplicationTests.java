package com.adminservice.systemadmin;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SystemAdminApplicationTests {

	@Test
	void contextLoads() {
	}

}
