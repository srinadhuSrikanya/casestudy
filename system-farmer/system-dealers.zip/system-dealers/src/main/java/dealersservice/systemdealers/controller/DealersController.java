package dealersservice.systemdealers.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import dealersservice.systemdealers.model.DealersDetails;
import dealersservice.systemdealers.repo.DealersRepository;

@RestController
public class DealersController {
	
	@Autowired
	DealersRepository repo;

	  @RequestMapping(value="/dealers/{DealerId}",method=RequestMethod.GET)
	  public Optional<DealersDetails> getDealersDetails(@PathVariable String DealerId) {
		return repo.findById(DealerId);
	  }

	  @RequestMapping(value="/adddealers",method=RequestMethod.POST)
	  public void addDealersDetails(@RequestBody DealersDetails dealers) {
		  repo.insert(dealers);
	  }

	  @RequestMapping(value="/dealers/{DealerId}",method=RequestMethod.PUT)
	  public void updateDealersDetails(@PathVariable String DealerId, @RequestBody DealersDetails dealers) {
		  repo.save(dealers);
	  }

	  @RequestMapping(value="/dealers/{DealerId}",method=RequestMethod.DELETE)
	  public void deleteDealersDetails(@PathVariable String DealerId) {
	    repo.deleteById(DealerId);
	  }
	
	

}
