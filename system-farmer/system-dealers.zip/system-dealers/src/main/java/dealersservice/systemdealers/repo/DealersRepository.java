package dealersservice.systemdealers.repo;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import dealersservice.systemdealers.model.DealersDetails;

@Repository
public interface DealersRepository extends MongoRepository<DealersDetails, String>{

}
