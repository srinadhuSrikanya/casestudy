package dealersservice.systemdealers;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SystemDealersApplicationTests {

	@Test
	void contextLoads() {
	}

}
